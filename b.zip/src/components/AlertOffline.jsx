import React from "react";
import { Alert } from "react-bootstrap";
export default function AlertOffline() {
  return <Alert variant={"danger"}>You are in offline</Alert>;
}
