export const FETCH_USERS = "FETCH_USERS";
export const POST_REQUEST = "POST_REQUEST";
export const GET_IMAGE = "GET_IMAGE";
export const GET_ALL_IMAGES = "GET_ALL_IMAGES";
